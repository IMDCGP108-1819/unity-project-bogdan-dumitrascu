﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ZigZag : MonoBehaviour
{

    //Making the asteroids move in a random squiggle pattern

    public float downSpeed;
    public float leftMargin;
    public float rightMargin;
    public float speed;
    private Rigidbody rb;

    private float t = 0f;

    private void Start()
    {
        rb = GetComponent<Rigidbody>();
        rb.velocity = -CalculateVelocity(leftMargin, leftMargin);
        StartCoroutine(ChangeDirection());
    }
    void FixedUpdate()
    {
        if (transform.position.x >= rightMargin || transform.position.x <= leftMargin)
        {
            rb.velocity = -rb.velocity;
        }
        transform.position -= new Vector3(0f, 0f, downSpeed);
    }

    private IEnumerator ChangeDirection()
    {

        while (gameObject.activeSelf)
        {
            if (Random.Range(0f, 1f) > 0.85f)
            {
                rb.velocity = -rb.velocity;
            }
            yield return new WaitForSecondsRealtime(0.1f);
        }
        yield return new WaitForSecondsRealtime(0.1f);
    }

    private Vector3 CalculateVelocity(float min, float max)
    {
        var x = Random.Range(min, max);
        var y = 0f;
        var z = 0f;
        return new Vector3(x, y, z);
    }
}