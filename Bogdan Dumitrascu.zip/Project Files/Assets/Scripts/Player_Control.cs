﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class Boundary
{
    public float xMin, xMax, zMin, zMax;
}

public class Player_Control : MonoBehaviour
{

    public float speed;
    public float tilt;
    public Boundary boundary;

    public GameObject shot1;
    public GameObject shot2;
    public GameObject shot1sound;
    public GameObject shot2sound;

    public Transform ShotSpawner;
    public Transform ShotSpawner1;
    public Transform ShotSpawner2;

    public float fireRate1;
    public float fireRate2;

    private float nextFire;
    

    //Storing the rigidbody component in the rb variable
    private Rigidbody rb;
    
    void Start ()
    {
        rb = GetComponent<Rigidbody>();
    }
    

    //Creating player shots, adding the fire rate and sounds for two types of attack
    void Update ()
    {
        if (Input.GetButton ("Fire1") && Time.time > nextFire)
        {
            nextFire = Time.time + fireRate1;
            Instantiate(shot1, ShotSpawner.position, ShotSpawner.rotation);
            Instantiate(shot1sound, transform.position, transform.rotation);
        }

        if (Input.GetButton("Fire2") && Time.time > nextFire)
        {
            nextFire = Time.time + fireRate2;
            Instantiate(shot2, ShotSpawner1.position, ShotSpawner1.rotation);
            Instantiate(shot2, ShotSpawner2.position, ShotSpawner2.rotation);
            Instantiate(shot2sound, transform.position, transform.rotation);
        }
    }
    


    //Moving the player ship
    void FixedUpdate()
    {
        float moveHorizontal = Input.GetAxis("Horizontal");
        float moveVertical = Input.GetAxis("Vertical");

        Vector3 movement = new Vector3(moveHorizontal, 0.0f, moveVertical);
        rb.velocity = movement * speed;
       

    //Creating boundaries so the player can't leave the play area
        rb.position = new Vector3
            (
                Mathf.Clamp(rb.position.x, boundary.xMin, boundary.xMax),
                0.0f,
                Mathf.Clamp (rb.position.z, boundary.zMin, boundary.zMax)
            );
           

    //Tilting the ship
        rb.rotation = Quaternion.Euler(0.0f, 0.0f, rb.velocity.x * -tilt);
        
    }
}
