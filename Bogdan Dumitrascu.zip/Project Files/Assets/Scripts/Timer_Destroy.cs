﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Timer_Destroy : MonoBehaviour
{
    //Destroying explosions effects

    public float lifetime;

    void Start()
    {
        Destroy(gameObject, lifetime);
    }
}
