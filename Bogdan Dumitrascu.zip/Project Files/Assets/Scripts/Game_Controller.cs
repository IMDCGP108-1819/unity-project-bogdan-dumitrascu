﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class Game_Controller : MonoBehaviour
{
    public GameObject hazard;
    public GameObject powerUp;
    public Vector3 spawnValues;
    public float spawnWait;
    public float startWait;
    public float waveWait;

    public Text scoreText;
    public int score;
    

    private int hazardcount = 5;

    void Start()
    {
        //Setting score = 0 and spawning the power up at the beginning of the game
        score = 0;
        UpdateScore();
        StartCoroutine(SpawnWaves());
        GameObject powerUpInstance = Instantiate(powerUp);
        powerUpInstance.transform.position = new Vector3(Random.Range(-spawnValues.x, spawnValues.x), spawnValues.y, spawnValues.z);
        powerUpInstance.transform.rotation = Quaternion.identity;
        DontDestroyOnLoad(gameObject);
    }

    IEnumerator SpawnWaves ()
    {
        //Pause at the start of the game before spawning hazards
        yield return new WaitForSeconds(startWait);

        //Spawning hazards randomly on x axis, setting time between spawns and increasing wave size every round
        while (true)
        {
            for (int i = 0; i < hazardcount; i++)
            {
                Vector3 spawnPosition = new Vector3(Random.Range(-spawnValues.x, spawnValues.x), spawnValues.y, spawnValues.z);
                Quaternion spawnRotation = Quaternion.identity;
                Instantiate(hazard, spawnPosition, spawnRotation);
                score += 20;
                UpdateScore();
                yield return new WaitForSeconds(spawnWait);
            }
            if (Random.Range(0f, 1f) < 0.2f)
            {
                GameObject powerUpInstance = Instantiate(powerUp);
                powerUpInstance.transform.position = new Vector3(Random.Range(-spawnValues.x, spawnValues.x), spawnValues.y, spawnValues.z);
                powerUpInstance.transform.rotation = Quaternion.identity;
            }
            hazardcount++;
            //Destroying the game controller
            if (SceneManager.GetActiveScene().buildIndex != 1)
            {
                StopAllCoroutines();
                Destroy(gameObject);
            }
            yield return new WaitForSeconds(waveWait);

            
        }
    }

    //Updating score during play
    public void AddScore (int newScoreValue)
    {
        score += newScoreValue;
        UpdateScore();
    }

    void UpdateScore()
    {
        if (scoreText == null)
        {
            return;
        }
        scoreText.text = "Score: " + score;
    }

    
}
