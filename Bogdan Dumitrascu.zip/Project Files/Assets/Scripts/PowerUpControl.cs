﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PowerUpControl : MonoBehaviour
{
    private float speed = 0.05f;
    private Rigidbody rb;

    public float tumble;

    //Making the power-up tumble
    private void Start()
    {
        rb = GetComponent<Rigidbody>();
        rb.angularVelocity = Random.insideUnitSphere * tumble;
    }
    //Power up movement
    void FixedUpdate()
    {
        transform.position -= new Vector3(0f, 0f, speed);
    }
    //Deactivating the power-up after the player touches it
    private void OnTriggerEnter(Collider collision)
    {
        if (collision.gameObject.tag == "Player")
        {
            StartCoroutine(DoubleFireRate(collision.gameObject.GetComponent<Player_Control>()));
            GetComponent<Renderer>().enabled = false;
            GetComponent<BoxCollider>().enabled = false;
        }
    }
    //Doubling the fire rate when power-up is collected then setting it back
    private IEnumerator DoubleFireRate(Player_Control player)
    {
        player.fireRate1 /= 2f;
        yield return new WaitForSecondsRealtime(3f);
        player.fireRate1 *= 2f;
        Destroy(gameObject);
    }
}
