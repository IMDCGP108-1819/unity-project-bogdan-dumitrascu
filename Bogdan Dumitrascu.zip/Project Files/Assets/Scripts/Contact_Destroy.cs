﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Contact_Destroy : MonoBehaviour
{
    //Destroying gameobjects after the collision effect

    public int life;
    public GameObject explosion;
    public GameObject playerExplosion;
    private Game_Controller gameController;
    private int i;
    public int scoreValue0;
    public int scoreValue1;

    private void Start()
    {
        gameController = GameObject.FindGameObjectWithTag("GameController").GetComponent<Game_Controller>();
    }

    void OnTriggerEnter(Collider other)
    {
        if (other.tag == "Boundary")
        {
            return;
        }
        Destroy(other.gameObject);
        i++;

        if (other.tag == "Heavy")
        {
            i = i + 6;
            if (i > life)
            {
                gameController.AddScore(scoreValue1);
                Destroy(gameObject);
                Instantiate(explosion, transform.position, transform.rotation);
            }
        }

        if (other.tag == "Player")
        {
            Instantiate(playerExplosion, other.transform.position, other.transform.rotation);
            Instantiate(explosion, transform.position, transform.rotation);
            SceneManager.LoadScene(2);
            Destroy(gameObject);
        }

        if (i == life)
        {
            gameController.AddScore(scoreValue0);
            Destroy(gameObject);
            Instantiate(explosion, transform.position, transform.rotation);
        }
    }
}