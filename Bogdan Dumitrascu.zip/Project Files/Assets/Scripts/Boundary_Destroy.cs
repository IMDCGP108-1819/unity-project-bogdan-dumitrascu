﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Boundary_Destroy : MonoBehaviour
{
    //Destroying objects as they touch the game area boundary

    private void OnTriggerExit(Collider other)
    {
        Destroy(other.gameObject);
    }
}
